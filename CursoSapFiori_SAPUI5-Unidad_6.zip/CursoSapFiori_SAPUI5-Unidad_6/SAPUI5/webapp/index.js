sap.ui.define([

], function () {
    alert("HOLA A TODOS");
});